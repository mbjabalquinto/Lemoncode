export const App = () => {
  return (
    <>
      <h1>Bootcamps JS - TypeScript React SandBox</h1>
    </>
  );
};
