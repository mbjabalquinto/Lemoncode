export default {
  rootDir: "../../",
  verbose: true,
  restoreMocks: true,
  moduleDirectories: ["<rootDir>/src", "node_modules"],
};
